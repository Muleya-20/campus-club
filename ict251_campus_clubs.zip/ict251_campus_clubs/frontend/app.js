const API = "/api/clubs";
const form = document.querySelector("#club-form");
const statusLine = document.querySelector("#status");
const tbody = document.querySelector("#clubs-body");
const countLine = document.querySelector("#count");
const formTitle = document.querySelector("#form-title");
const saveButton = document.querySelector("#save-button");
const fieldNames = ["name", "category", "description", "meeting_day", "meeting_time", "location", "contact_email"];

function showStatus(message, isError = false) {
  statusLine.textContent = message;
  statusLine.style.color = isError ? "#a52b38" : "#17633a";
}

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[char]);
}

async function request(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) }
  });
  const result = await response.json();
  if (!response.ok) {
    throw new Error((result.errors || [result.message || "Request failed"]).join(" "));
  }
  return result;
}

async function loadClubs() {
  try {
    const result = await request(API);
    countLine.textContent = `${result.count} club(s) found`;
    if (result.data.length === 0) {
      tbody.innerHTML = '<tr><td colspan="7">No clubs yet. Add one using the form.</td></tr>';
      return;
    }
    tbody.innerHTML = result.data.map(club => `
      <tr>
        <td>${club.id}</td>
        <td><strong>${escapeHTML(club.name)}</strong><br><span class="muted">${escapeHTML(club.description)}</span></td>
        <td>${escapeHTML(club.category)}</td>
        <td>${escapeHTML(club.meeting_day)}<br>${escapeHTML(club.meeting_time)}</td>
        <td>${escapeHTML(club.location)}</td>
        <td>${escapeHTML(club.contact_email)}</td>
        <td>
          <button type="button" data-edit="${club.id}">Edit</button>
          <button type="button" class="danger" data-delete="${club.id}">Delete</button>
        </td>
      </tr>`).join("");
  } catch (error) {
    showStatus(`Could not load clubs: ${error.message}`, true);
    tbody.innerHTML = '<tr><td colspan="7">Could not load data. Is the Node server running?</td></tr>';
  }
}

function resetForm() {
  form.reset();
  document.querySelector("#club-id").value = "";
  formTitle.textContent = "Add a club";
  saveButton.textContent = "Save club";
}

form.addEventListener("submit", async event => {
  event.preventDefault();
  const id = document.querySelector("#club-id").value;
  const data = Object.fromEntries(fieldNames.map(name => [
    name, document.querySelector(`#${name}`).value.trim()
  ]));
  try {
    const result = await request(id ? `${API}/${id}` : API, {
      method: id ? "PUT" : "POST",
      body: JSON.stringify(data)
    });
    showStatus(result.message || (id ? "Club updated." : "Club created."));
    resetForm();
    await loadClubs();
  } catch (error) {
    showStatus(error.message, true);
  }
});

tbody.addEventListener("click", async event => {
  const editButton = event.target.closest("[data-edit]");
  const deleteButton = event.target.closest("[data-delete]");

  if (editButton) {
    try {
      const result = await request(`${API}/${editButton.dataset.edit}`);
      const club = result.data;
      document.querySelector("#club-id").value = club.id;
      fieldNames.forEach(name => {
        document.querySelector(`#${name}`).value = club[name] ?? "";
      });
      formTitle.textContent = `Edit club #${club.id}`;
      saveButton.textContent = "Save changes";
      showStatus(`Loaded ${club.name} for editing.`);
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (error) {
      showStatus(error.message, true);
    }
  }

  if (deleteButton) {
    const id = deleteButton.dataset.delete;
    if (!window.confirm(`Delete club #${id}? This cannot be undone.`)) return;
    try {
      const result = await request(`${API}/${id}`, { method: "DELETE" });
      showStatus(result.message);
      if (document.querySelector("#club-id").value === id) resetForm();
      await loadClubs();
    } catch (error) {
      showStatus(error.message, true);
    }
  }
});

document.querySelector("#cancel-button").addEventListener("click", () => {
  resetForm();
  showStatus("Form cleared.");
});
document.querySelector("#refresh-button").addEventListener("click", loadClubs);

loadClubs();
