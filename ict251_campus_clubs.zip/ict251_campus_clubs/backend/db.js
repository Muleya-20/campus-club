const fs = require("node:fs");
const path = require("node:path");
const Database = require("better-sqlite3");
require("dotenv").config({ path: path.resolve(__dirname, "..", ".env") });

const configuredPath = process.env.DB_PATH || "./backend/clubs.db";
const dbPath = path.resolve(__dirname, "..", configuredPath);
fs.mkdirSync(path.dirname(dbPath), { recursive: true });

const db = new Database(dbPath);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

// Apply the one-table schema and sample data when the server starts.
const schema = fs.readFileSync(path.join(__dirname, "schema.sql"), "utf8");
db.exec(schema);

module.exports = db;
