const path = require("node:path");
require("dotenv").config({ path: path.resolve(__dirname, "..", ".env") });

const express = require("express");
const cors = require("cors");
const db = require("./db");

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "..", "frontend")));

const fields = [
  "name",
  "category",
  "description",
  "meeting_day",
  "meeting_time",
  "location",
  "contact_email"
];

function validateClub(body) {
  const errors = [];
  for (const field of fields) {
    if (typeof body[field] !== "string" || body[field].trim() === "") {
      errors.push(`${field} is required and must be text.`);
    }
  }
  if (typeof body.contact_email === "string" &&
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(body.contact_email.trim())) {
    errors.push("contact_email must be a valid email address.");
  }
  return errors;
}

// GET: retrieve all club records.
app.get("/api/clubs", (req, res) => {
  const clubs = db.prepare("SELECT * FROM clubs ORDER BY id").all();
  res.json({ success: true, count: clubs.length, data: clubs });
});

// GET: retrieve one record by its ID.
app.get("/api/clubs/:id", (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1) {
    return res.status(400).json({ success: false, message: "ID must be a positive integer." });
  }

  const club = db.prepare("SELECT * FROM clubs WHERE id = ?").get(id);
  if (!club) {
    return res.status(404).json({ success: false, message: "Club not found." });
  }
  res.json({ success: true, data: club });
});

// POST: create a new club record.
app.post("/api/clubs", (req, res) => {
  const errors = validateClub(req.body || {});
  if (errors.length) {
    return res.status(400).json({ success: false, errors });
  }

  const club = Object.fromEntries(fields.map(field => [field, req.body[field].trim()]));
  const result = db.prepare(`
    INSERT INTO clubs (${fields.join(", ")})
    VALUES (${fields.map(() => "?").join(", ")})
  `).run(...fields.map(field => club[field]));

  const created = db.prepare("SELECT * FROM clubs WHERE id = ?").get(result.lastInsertRowid);
  res.status(201).json({ success: true, message: "Club created.", data: created });
});

// PUT: update an existing club record.
app.put("/api/clubs/:id", (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1) {
    return res.status(400).json({ success: false, message: "ID must be a positive integer." });
  }

  const existing = db.prepare("SELECT * FROM clubs WHERE id = ?").get(id);
  if (!existing) {
    return res.status(404).json({ success: false, message: "Club not found." });
  }

  const errors = validateClub(req.body || {});
  if (errors.length) {
    return res.status(400).json({ success: false, errors });
  }

  const club = Object.fromEntries(fields.map(field => [field, req.body[field].trim()]));
  db.prepare(`
    UPDATE clubs
    SET ${fields.map(field => `${field} = ?`).join(", ")},
        updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).run(...fields.map(field => club[field]), id);

  const updated = db.prepare("SELECT * FROM clubs WHERE id = ?").get(id);
  res.json({ success: true, message: "Club updated.", data: updated });
});

// DELETE: remove a club record by ID.
app.delete("/api/clubs/:id", (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1) {
    return res.status(400).json({ success: false, message: "ID must be a positive integer." });
  }

  const result = db.prepare("DELETE FROM clubs WHERE id = ?").run(id);
  if (result.changes === 0) {
    return res.status(404).json({ success: false, message: "Club not found." });
  }
  res.json({ success: true, message: `Club ${id} deleted.` });
});

// JSON error handler for malformed JSON and unexpected errors.
app.use((err, req, res, next) => {
  if (err instanceof SyntaxError && "body" in err) {
    return res.status(400).json({ success: false, message: "Request body contains invalid JSON." });
  }
  console.error(err);
  res.status(500).json({ success: false, message: "Internal server error." });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Campus Clubs app running at http://localhost:${PORT}`);
  console.log(`API endpoint: http://localhost:${PORT}/api/clubs`);
});
