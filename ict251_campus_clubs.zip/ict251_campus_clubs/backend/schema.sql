CREATE TABLE IF NOT EXISTS clubs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    description TEXT NOT NULL,
    meeting_day TEXT NOT NULL,
    meeting_time TEXT NOT NULL,
    location TEXT NOT NULL,
    contact_email TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO clubs
(name, category, description, meeting_day, meeting_time, location, contact_email)
SELECT 'Coding Club', 'Technology', 'Students learn programming and build small projects.', 'Monday', '14:00', 'Computer Lab 1', 'coding@example.com'
WHERE NOT EXISTS (SELECT 1 FROM clubs WHERE name = 'Coding Club');

INSERT INTO clubs
(name, category, description, meeting_day, meeting_time, location, contact_email)
SELECT 'Debate Society', 'Academic', 'Members practise public speaking and structured debates.', 'Tuesday', '15:00', 'Lecture Room A', 'debate@example.com'
WHERE NOT EXISTS (SELECT 1 FROM clubs WHERE name = 'Debate Society');

INSERT INTO clubs
(name, category, description, meeting_day, meeting_time, location, contact_email)
SELECT 'Environmental Club', 'Community', 'Students organise clean-ups and environmental awareness activities.', 'Wednesday', '13:00', 'Student Centre', 'environment@example.com'
WHERE NOT EXISTS (SELECT 1 FROM clubs WHERE name = 'Environmental Club');

INSERT INTO clubs
(name, category, description, meeting_day, meeting_time, location, contact_email)
SELECT 'Drama Club', 'Arts', 'Members rehearse plays and perform campus theatre.', 'Thursday', '16:00', 'Arts Hall', 'drama@example.com'
WHERE NOT EXISTS (SELECT 1 FROM clubs WHERE name = 'Drama Club');

INSERT INTO clubs
(name, category, description, meeting_day, meeting_time, location, contact_email)
SELECT 'Photography Club', 'Arts', 'Students practise photography and share creative work.', 'Friday', '14:30', 'Library Garden', 'photo@example.com'
WHERE NOT EXISTS (SELECT 1 FROM clubs WHERE name = 'Photography Club');

INSERT INTO clubs
(name, category, description, meeting_day, meeting_time, location, contact_email)
SELECT 'Chess Club', 'Games', 'Members play friendly chess matches and learn strategies.', 'Monday', '16:00', 'Common Room', 'chess@example.com'
WHERE NOT EXISTS (SELECT 1 FROM clubs WHERE name = 'Chess Club');

INSERT INTO clubs
(name, category, description, meeting_day, meeting_time, location, contact_email)
SELECT 'Music Club', 'Music', 'Students share music, practise instruments and plan performances.', 'Tuesday', '17:00', 'Music Room', 'music@example.com'
WHERE NOT EXISTS (SELECT 1 FROM clubs WHERE name = 'Music Club');

INSERT INTO clubs
(name, category, description, meeting_day, meeting_time, location, contact_email)
SELECT 'Entrepreneurs Club', 'Business', 'Members explore business ideas and startup skills.', 'Wednesday', '15:00', 'Business Block 2', 'startup@example.com'
WHERE NOT EXISTS (SELECT 1 FROM clubs WHERE name = 'Entrepreneurs Club');

INSERT INTO clubs
(name, category, description, meeting_day, meeting_time, location, contact_email)
SELECT 'Sports Club', 'Sports', 'Members coordinate recreational games and fitness activities.', 'Thursday', '14:00', 'Sports Ground', 'sports@example.com'
WHERE NOT EXISTS (SELECT 1 FROM clubs WHERE name = 'Sports Club');

INSERT INTO clubs
(name, category, description, meeting_day, meeting_time, location, contact_email)
SELECT 'Reading Club', 'Academic', 'Members discuss books and practise reading together.', 'Friday', '13:00', 'Main Library', 'reading@example.com'
WHERE NOT EXISTS (SELECT 1 FROM clubs WHERE name = 'Reading Club');
