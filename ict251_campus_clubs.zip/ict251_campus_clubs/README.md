# ICT251 Activity 4 — Campus Club CRUD App

## Requirements
- Node.js 20 or newer and npm
- Internet connection for the first `npm install`
- Postman (desktop app or web app with Desktop Agent)

## Run on Linux Mint
Open Terminal and run:

```bash
sudo apt update
sudo apt install -y curl ca-certificates build-essential python3 make g++
```

Install Node.js from the NodeSource 22.x repository if `node` is not installed:
```bash
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs
```

Check versions:
```bash
node --version
npm --version
```

Then, from this project folder:
```bash
npm install
npm start
```

Open http://localhost:3000 in your browser. Leave the terminal running while using the app.

## API endpoints
- `GET http://localhost:3000/api/clubs`
- `GET http://localhost:3000/api/clubs/1`
- `POST http://localhost:3000/api/clubs`
- `PUT http://localhost:3000/api/clubs/1`
- `DELETE http://localhost:3000/api/clubs/1`

POST and PUT body must be JSON, e.g.
```json
{
  "name": "Robotics Club",
  "category": "Technology",
  "description": "Students design and test robotics projects.",
  "meeting_day": "Friday",
  "meeting_time": "15:00",
  "location": "Engineering Lab",
  "contact_email": "robotics@example.com"
}
```

## Database
SQLite database is created automatically at `backend/clubs.db`. The schema is in `backend/schema.sql`. It contains one table (`clubs`) and 10 seed records.

## Important
- Use `localhost` only for local testing. For cloud submission, deploy the backend to a hosting provider that supports persistent storage, or use a managed database. Some serverless hosts have ephemeral filesystems, so a local SQLite file may reset after deployment.
- Record your own Postman video evidence; do not submit fabricated screenshots.
